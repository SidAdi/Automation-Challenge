package automation;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.apache.commons.io.FileUtils;
import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeTest;

public class AutomationCode {
	public static 	WebDriver driver;
	String url="http://automationpractice.com/index.php";
 
    @Before
	public void setUp() {
		String browserType="chrome";
		switch (browserType) {
		case "firefox":
			System.setProperty("webdriver.gecko.driver","F:\\geckodriver\\geckodriver.exe");
			driver = new FirefoxDriver();
			break;
		case "chrome":
			System.setProperty("webdriver.chrome.driver","F:\\chromedriver\\chromedriver.exe");
			driver = new ChromeDriver();
			break;
		}
	   
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.get(url);
	}
	
	@Test
	public void testCases() throws IOException, Exception {
		driver.findElement(By.xpath("//a[@class='login']")).click();
		driver.findElement(By.id("email_create")).sendKeys("adcczllac@gmail.com");
		driver.findElement(By.xpath("//button[@id='SubmitCreate']")).click();
		driver.findElement(By.id("id_gender1")).click();
		driver.findElement(By.id("customer_firstname")).sendKeys("fzgldfsd");
		driver.findElement(By.id("customer_lastname")).sendKeys("fkgdfzgsdxcc");

		driver.findElement(By.id("passwd")).sendKeys("dfejhkzddf");

		WebElement day=driver.findElement(By.id("days"));

		Select sec=new Select(day);
		sec.selectByValue("1");

		WebElement mon=driver.findElement(By.id("months"));

		Select sel=new Select(mon);
		sel.selectByValue("1");

		WebElement yr=driver.findElement(By.id("years"));

		Select se=new Select(yr);
		se.selectByValue("1997");


		String path=System.getProperty("C:\\Users\\Dhanunjay Reddy\\Desktop\\Details.xlsx");
		Thread.sleep(2000);
		FileInputStream fi=new FileInputStream(path);
		XSSFWorkbook wrkbok=new XSSFWorkbook(fi);
		XSSFSheet shet=wrkbok.getSheet("Sheet1");

		int rwcnt=shet.getLastRowNum()-shet.getFirstRowNum();
		System.out.println(rwcnt);
		for(int i=1;i<=rwcnt;i++){
			String address=shet.getRow(i).getCell(2).getStringCellValue();
			String city=shet.getRow(i).getCell(3).getStringCellValue();
			String state=shet.getRow(i).getCell(4).getStringCellValue();
			String postalcode=shet.getRow(i).getCell(5).getStringCellValue();
		
			String mobileno=shet.getRow(i).getCell(7).getStringCellValue();
			driver.findElement(By.id("address1")).sendKeys(address);
			driver.findElement(By.id("city")).sendKeys(city);
			WebElement stat=driver.findElement(By.id("id_state"));

			Select selec=new Select(stat);
			selec.selectByVisibleText(state);
			driver.findElement(By.id("postcode")).sendKeys(postalcode);
			driver.findElement(By.id("phone_mobile")).sendKeys(mobileno);
			driver.findElement(By.id("submitAccount")).click();
		}
		wrkbok.close();

		try{
			Assert.assertEquals("My account", driver.getTitle());
			System.out.println("Navigated to correct webpage");
		}
		catch(Throwable pageNavigationError){
			System.out.println("Didn't navigate to correct webpage");
		}

		driver.findElement(By.xpath("//a[@title='Home']")).click();
		driver.findElement(By.xpath("(//a[@title='Dresses'])[2]")).click();

		WebElement from=driver.findElement(By.xpath("(//a[@title='Printed Dress'])[1]"));
		WebElement to=driver.findElement(By.xpath("(//a[@title='Add to cart'])[1]"));
		if (driver.findElement(By.xpath("(//span[@class='price product-price'])[1]")).isDisplayed() && driver.findElement(By.xpath("(//a[@title='Add to cart'])[1]")).isDisplayed()) {
		
		    System.out.print("Cost value and Add to cart button are Displayed");
		}
		System.out.print("Cost value and Add to cart button are not Displayed");
		Actions action=new Actions(driver);
		action.moveToElement(from).moveToElement(to).click().build().perform();
		
		if(driver.findElement(By.xpath("//a[@title='Proceed to checkout']")).isDisplayed()) {
			System.out.println("Proceed to checkout is Displayed");
		}
		System.out.println("Proceed to checkout is not Displayed");
	

		driver.findElement(By.xpath("//a[@title='Proceed to checkout']")).click();
		driver.findElement(By.xpath("(//a[@title='Proceed to checkout'])[2]")).click();
		String addres1=driver.findElement(By.xpath("(//li[@class='address_address1 address_address2'])[1]")).getText();
		String addres2=driver.findElement(By.xpath("(//li[@class='address_address1 address_address2'])[2]")).getText();
		if (addres1==addres2) {
			System.out.println("Delivery address and Billing address are same");
		}
		System.out.println("Delivery address and Billing address are different");
		driver.findElement(By.name("processAddress")).click();
		driver.findElement(By.name("processCarrier")).click();

		String msg1 = driver.switchTo().alert().getText();
		if (msg1=="You must agree to the terms of service before continuing."){
			System.out.print("Success");
		}
		System.out.print("Fail");
		driver.findElement(By.xpath("//a[@title='Close']")).click();
		driver.findElement(By.id("cgv")).click();
		driver.findElement(By.name("processCarrier")).click();

		driver.findElement(By.xpath("//a[@class='bankwire']")).click();
		String msg2 = driver.findElement(By.xpath("//span[@class='navigation_page']")).getText();
		if (msg2=="Bank-wire payment."){
			System.out.print("Bank-wire payment is Displayed");
		}
		System.out.print("Bank-wire payment is Displayed");
		driver.findElement(By.xpath("(//button[@type='submit'])[2]")).click();
		driver.findElement(By.xpath("//a[@title='Back to orders']")).click();
		if (driver.findElement(By.xpath("(//a[@class='color-myaccount'])[1]")).isDisplayed()) {
			System.out.println("Order reference is Displayed");
		}
		System.out.println("Order reference is not Displayed");
		if(driver.findElement(By.xpath("(//td[@class='history_date bold'])[1]")).isDisplayed() && driver.findElement(By.xpath("(//td[@class='history_price'])[1]")).isDisplayed()) {
			System.out.println("Price and Date are Displayed");
		}
		System.out.println("Price and Date are not Displayed");
		File scrFile = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
		FileUtils.copyFile(scrFile, new File("F:\\Eclipse-Workspace\\AutomationChallenge\\Image.PNG"));
	}
	@After
	public void tearDown() {
		driver.quit();
	}
}
