package com.infy.base;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;

import com.infy.utilities.ExcelReader;

public class TestBase {

	public static WebDriver driver;
	
	public static Properties config=new Properties();
	public static Properties OR =new Properties();
	public static FileInputStream fis;
	public static String BrowserName ="chrome";
	public static Logger log=Logger.getLogger("devpinoyLogger");
	public static ExcelReader excel =new ExcelReader("C:\\Users\\sd25499\\eclipse-workspace\\AutomationChallenge\\resources\\excel\\testdata.xlsx");

	public static void SetUp() throws IOException {
		
		
		FileInputStream ip =new FileInputStream("C:\\Users\\sd25499\\eclipse-workspace\\AutomationChallenge\\resources\\properties\\config.properties");
		config.load(ip);
		
		FileInputStream it =new FileInputStream("C:\\Users\\sd25499\\eclipse-workspace\\AutomationChallenge\\resources\\properties\\OR.properties");
		OR.load(it);
		
		if(driver==null)
		{
			if(BrowserName.equalsIgnoreCase("chrome"))
			{
				//System.setProperty("webdriver.chrome.driver","C:\\Users\\sd25499\\eclipse-workspace\\AutomationChallenge\\resources\\executables\\chromedriver.exe");
				//System.setProperty("webdriver.chrome.driver","C:\\Users\\sd25499\\Work Folders\\Downloads\\drivers\\chromedriver.exe");
				System.setProperty("webdriver.chrome.driver","C:\\Users\\sd25499\\drivers\\chrome\\chromedriver.exe");
				driver=new ChromeDriver();
				log.debug("Chrome Browser Launced");
			}
			else if(BrowserName.equalsIgnoreCase("FF"))
			{
				System.setProperty("webdriver.firefox.marionette","C:\\Users\\sd25499\\eclipse-workspace\\AutomationChallenge\\resources\\executables\\geckodriver.exe");
				driver=new FirefoxDriver();
				log.debug("Firefox Browser Launced");
			}
			else if(BrowserName.equalsIgnoreCase("IE"))
			{
				System.setProperty("webdriver.ie.driver","C:\\Users\\sd25499\\eclipse-workspace\\AutomationChallenge\\resources\\executables\\IEDriverServer.exe");
				driver=new InternetExplorerDriver();
				log.debug("Internet Explorer Browser Launced");
			}
		}
		
		driver.manage().deleteAllCookies();
		driver.manage().timeouts().implicitlyWait(20,TimeUnit.SECONDS);
		driver.manage().timeouts().pageLoadTimeout(20, TimeUnit.SECONDS);
		driver.manage().window().maximize();
		String url =config.getProperty("TestSiteUrl");
		
		driver.get(url);
		log.debug("Test Url is entered and application is launced");
	}

	public static void TearDown() {
		driver.quit();
		driver =null;
		
		log.debug("Browser closed");

	}

}
