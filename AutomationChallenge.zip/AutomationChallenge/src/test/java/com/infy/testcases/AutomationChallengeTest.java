package com.infy.testcases;

import java.io.File;
import java.io.IOException;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.infy.base.TestBase;

public class AutomationChallengeTest extends TestBase {

	
	
	@BeforeSuite
	public void initialize() throws IOException
	{
		TestBase.SetUp();
	}
	
	@Test(dataProvider ="getData")
	public void SignInTest(String PIFirstName,String PILastName,String password
			,String address,String City) throws InterruptedException
	{
		String title =TestBase.driver.getTitle();
		driver.findElement(By.xpath(OR.getProperty("SignInButton_Xpath"))).click();
		log.debug("Clicked on Sign In Button");
		driver.findElement(By.xpath(OR.getProperty("EmailAddress_Xpath"))).sendKeys("siddharthdas1333@gmail.com");
		log.debug("Email Address Entered");
		driver.findElement(By.id(OR.getProperty("SubmitButton_ID"))).click();
		log.debug("Clicked on Submit Button");
		driver.findElement(By.id(OR.getProperty("Title_ID"))).click();
	    log.debug("Clicked on Title Radio button");
	    driver.findElement(By.id(OR.getProperty("FirstName_ID"))).sendKeys(PIFirstName);
	    driver.findElement(By.id(OR.getProperty("LastName_ID"))).sendKeys(PILastName);
	    driver.findElement(By.id(OR.getProperty("Password_ID"))).sendKeys(password);
	    log.debug("Entered First Name,Last Name and Password under Your Personal Information Section");
	   
	    driver.findElement(By.id(OR.getProperty("Address_ID"))).sendKeys(address);
	    driver.findElement(By.id(OR.getProperty("City_ID"))).sendKeys(City);
	    
	    WebElement state=driver.findElement(By.id(OR.getProperty("state_ID")));
	    Select selectstate=new Select(state);
	    selectstate.selectByIndex(4);
	    log.debug("State is entered from the drop down menu");
	    
	    driver.findElement(By.id(OR.getProperty("PostalCode_ID"))).sendKeys("00000");
	    log.debug("Postal Code is entered");
	    
	    WebElement country=driver.findElement(By.id(OR.getProperty("country_ID")));
	    Select selectcountry=new Select(country);
	    selectcountry.selectByIndex(1);
	    log.debug("Country is selected from the drop down");
	    
	    driver.findElement(By.id(OR.getProperty("PhoneNumber_ID"))).sendKeys("9668543971");
	    log.debug("Phone number is entered");
	    Thread.sleep(5000);
	    driver.findElement(By.id(OR.getProperty("SubmitFormButton"))).click();
	    log.debug("All values are entered in the form and then clicked on the submit Button");
	    
	    
	    
	}
	@DataProvider
	public Object[][] getData(){
		
		String sheetName ="SignInTest";
		int rows =excel.getRowCount(sheetName);
		int cols =excel.getColumnCount(sheetName);
		
		Object[][] data =new Object[rows-1][cols];
		
		for(int rowNum =2;rowNum<=rows;rowNum++)
		{
			for (int colNum =0;colNum<cols;colNum++)
			{
				data[rowNum-2][colNum]=excel.getCellData(sheetName,colNum,rowNum);
			}
			
		}
		return data;
		
	}
	
	@Test
	public void HomePageTest() throws IOException
	{
		try{
			Assert.assertEquals("My account", driver.getTitle());
			System.out.println("Navigated to correct webpage");
			log.debug("Navigated to the correct webpage");

		}
		catch(Throwable pageNavigationError){
			System.out.println("Didn't navigate to correct webpage");
			log.debug("Did not navigate to the correct webpage");
		}

		driver.findElement(By.xpath(OR.getProperty("HomeLink_Xpath"))).click();
		log.debug("Clicked on the Home Link");
		driver.findElement(By.xpath(OR.getProperty("DressesLink_Xpath"))).click();
		log.debug("Clicked on the Dresses Link");

		WebElement from=driver.findElement(By.xpath(OR.getProperty("PrintedDress_Xpath")));
		WebElement to=driver.findElement(By.xpath(OR.getProperty("AddToCart_Xpath")));
		if (driver.findElement(By.xpath(OR.getProperty("PriceOfProduct_Xpath"))).isDisplayed() && driver.findElement(By.xpath(OR.getProperty("AddToCart_Xpath"))).isDisplayed()) {
		
		    System.out.print("Cost value and Add to cart button are Displayed");
		}
		System.out.print("Cost value and Add to cart button are not Displayed");
		Actions action=new Actions(driver);
		action.moveToElement(from).moveToElement(to).click().build().perform();
		
		if(driver.findElement(By.xpath(OR.getProperty("ProceedToCheckout_Xpath"))).isDisplayed()) {
			System.out.println("Proceed to checkout is Displayed");
		}
		System.out.println("Proceed to checkout is not Displayed");
	

		driver.findElement(By.xpath(OR.getProperty("ProceedToCheckout_Xpath"))).click();
		log.debug("Clicked on Proceed to Checkout Button");
		driver.findElement(By.xpath(OR.getProperty("CheckoutButton_Xpath"))).click();
		String addres1=driver.findElement(By.xpath(OR.getProperty("Address1_Xpath"))).getText();
		String addres2=driver.findElement(By.xpath(OR.getProperty("Address2_Xpath"))).getText();
		if (addres1==addres2) {
			System.out.println("Delivery address and Billing address are same");
		}
		System.out.println("Delivery address and Billing address are different");
		driver.findElement(By.name("processAddress")).click();
		log.debug("Clicked on Process Address");
		driver.findElement(By.name("processCarrier")).click();
		log.debug("Clicked on Process Carrier");

		String msg1 = driver.switchTo().alert().getText();
		if (msg1=="You must agree to the terms of service before continuing."){
			System.out.print("Success");
		}
		System.out.print("Fail");
		driver.findElement(By.xpath("Closebutton_Xpath")).click();
		driver.findElement(By.id("cgv")).click();
		driver.findElement(By.name("processCarrier")).click();

		driver.findElement(By.xpath(OR.getProperty("Bank_Xpath"))).click();
		String msg2 = driver.findElement(By.xpath("Navigation_Xpath")).getText();
		if (msg2=="Bank-wire payment."){
			System.out.print("Bank-wire payment is Displayed");
			log.debug("Bank Wire payment is displayed");
		}
		System.out.print("Bank-wire payment is Displayed");
		driver.findElement(By.xpath(OR.getProperty("Submit_Xpath"))).click();
		driver.findElement(By.xpath(OR.getProperty("BackOrders_Xpath"))).click();
		if (driver.findElement(By.xpath(OR.getProperty("MyAccount_Xpath"))).isDisplayed()) {
			System.out.println("Order reference is Displayed");
			log.debug("Reference is displayed");
		}
		System.out.println("Order reference is not Displayed");
		if(driver.findElement(By.xpath(OR.getProperty("HistoryData_Xpath"))).isDisplayed() && driver.findElement(By.xpath(OR.getProperty("HistoryPrice_Xpath"))).isDisplayed()) {
			System.out.println("Price and Date are Displayed");
			log.debug("History Price and Date are Displayed");
		}
		System.out.println("Price and Date are not Displayed");
		File scrFile = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
		FileUtils.copyFile(scrFile, new File("F:\\Eclipse-Workspace\\AutomationChallenge\\Image.PNG"));
		
	}
	
	@AfterSuite
	public void close()
	{
		//TestBase.TearDown();
	}
}
